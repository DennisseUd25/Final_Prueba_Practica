# Herramientas


[Multiples herramientas de Python para realizar Pentest - By Dloss](https://github.com/dloss/python-pentest-tools)

[Shodan](https://www.shodan.io/)

[Virtustotal](https://www.virustotal.com/gui/home/upload)

[Masscan](https://github.com/robertdavidgraham/masscan)

[Metadefender (OPSWAT)](https://metadefender.opswat.com/#!/)

[Free Malware Sample Sources for Researchers](https://zeltser.com/malware-sample-sources/)
