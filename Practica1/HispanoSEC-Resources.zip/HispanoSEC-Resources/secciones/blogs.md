# Blogs



[El lado del mal (Chema Alonso)](https://www.elladodelmal.com/)

[Hacker Players](https://www.hackplayers.com/)

[The Hacker News](https://thehackernews.com/)

[Linuxito](https://www.linuxito.com/)

[Criptored](http://www.criptored.upm.es/)

[TroyHunt](https://www.troyhunt.com/)

[Corelan](https://www.corelan.be/)

